% Example of a sparse reconstruction of an incomplete Relative Transfer 
% Function (RTF) using SpaRIR
%
% Z. Koldovsk�, J. M�lek, and S. Gannot, "Spatial Source Subtraction 
% Based on Incomplete Measurements of Relative Transfer Function," 
% IEEE/ACM Trans. on Speech, Audio and Language Processing, vol. 23, no. 8, 
% pp. 1335 - 1347, August 2015
%
% See also
%
% Z. Koldovsk� and P. Tichavsk�, "Sparse Reconstruction of Incomplete 
% Relative Transfer Function: Discrete and Continuous Time Domain," The 
% 23rd European Signal Processing Conference (EUSIPCO 2015), Nice, France, 
% Sept. 2015.
%

clear *

interval = 1:32000; % interval of data for testing (estimation + ATR evaluation)
Fs = 16000; % sampling frequency


L=2048; % filter length == FFT resolution
FFTSHIFT = 32; 
D=100; % delay of the RTF estimates

percentage = 40; % percents of frequency bins that will be dropped when 
%                  building the incomplete RTF

load demofiles1 % directional white noise
% load demofiles % bubble noise
% x ... noisy stereo recording
% resp ... original stereo recordings of the target signal and of the noise 


ATRfun = inline('10*log10(mean(BMoutput(signal,h,D).^2)/mean(BMoutput(noise,h,D).^2))',...
    'signal','noise','h','D'); % a function to compute Attenuation Rate (ATR), 
                         % which is the Signal-to-Noise ratio at the output of 
                         % the target-signal-blocking (spatial) filter


%% Oracle Estimators

% Time-domain noise-free RTF estimate from test interval
h_TD = TDRTF(L,resp(1,interval,1)',resp(2,interval,1)',D);
ATR_oracle_TD = ATRfun(resp(:,interval,1)',resp(:,interval,2)',h_TD,D);

% Conventional frequency-domain noise-free RTF estimate
h_FD = FDRTF(L,resp(1,interval,1)',resp(2,interval,1)',D,FFTSHIFT);
ATR_oracle_FD = ATRfun(resp(:,interval,1)',resp(:,interval,2)',h_FD,D);

% Frequency domain nonstationarity-based noise-free estimate coded by Sharon Gannot
[~,h_NSFD] = est2frq1(resp(1,interval,1),resp(2,interval,1),...
    [1:250:length(interval)+1-1000; 1000:250:length(interval)]',D,L-D-1);
ATR_oracle_NSFD = ATRfun(resp(:,interval,1)',resp(:,interval,2)',h_NSFD,D);

%% Noisy Estimates

% Conventional frequency-domain RTF estimate from noisy data
g_FD = FDRTF(L,x(1,interval)',x(2,interval)',D,FFTSHIFT);
ATR_FD = ATRfun(resp(:,interval,1)',resp(:,interval,2)',g_FD,D);

% Frequency domain nonstationarity-based noisy estimate coded by Sharon Gannot
[~,g_NSFD]=est2frq1(x(1,interval),x(2,interval),...
    [1:250:length(interval)+1-1000; 1000:250:length(interval)]',D,L-D-1);
ATR_NSFD = ATRfun(resp(:,interval,1)',resp(:,interval,2)',g_NSFD,D);

%% Building incomplete RTF from g_NSFD
weights = 0.1*exp(0.11*abs((1:L)'-D).^0.3);

G_FD = fft(g_FD); % complete RTF estimate by FD
G_NSFD = fft(g_NSFD'); % complete RTF estimate by NSFD

%% Oracle selection of frequency bins based on input SNR on the left
% microphone
isnr = sum(abs(stft(resp(1,interval,1),L,FFTSHIFT,L,ones(L,1))).^2,2)./...
    sum(abs(stft(resp(1,interval,2),L,FFTSHIFT,L,ones(L,1))).^2,2);
isnr = isnr(1:L/2);
[~ , order] = sort(isnr,'descend');
S = false(L,1);
S(order(1:ceil(percentage/100*L/2))) = true; % the set of selected 
% frequency bins, i.e., SpaRIR uses only the values of G_NSFD(S)

% Sparse reconstruction of the relative impulse response
g_oracle_sparse_FD = SpaRIR(G_FD,S,D,weights,1);
ATR_oracle_sparse_FD_1 = ATRfun(resp(:,interval,1)',resp(:,interval,2)',g_oracle_sparse_FD,D);
g_oracle_sparse = SpaRIR(G_NSFD,S,D,weights,1);
ATR_oracle_sparse_1 = ATRfun(resp(:,interval,1)',resp(:,interval,2)',g_oracle_sparse,D);

% Sparse reconstruction of the relative impulse response with oversampling
% factor 4
g_oracle_sparse_2 = SpaRIR(G_NSFD,S,D,weights,2);
ATR_oracle_sparse_2 = ATRfun(resp(:,interval,1)',resp(:,interval,2)',g_oracle_sparse_2,D);

%% Kurtosis-based selection of frequency bins 
XL=stft(x(1,interval),L,FFTSHIFT);
kurt=(mean(abs(XL).^4,2)-abs(mean(XL.^2,2)).^2)./mean(abs(XL).^2,2).^2 - 2; 
kurt = kurt(1:L/2);
[~ , order] = sort(kurt,'descend');
S = false(L,1);
S(order(1:ceil(percentage/100*L/2))) = true;

% Sparse reconstruction of the relative impulse response
g_kurt_sparse_FD = SpaRIR(G_FD,S,D,weights,1);
ATR_kurt_sparse_FD_1 = ATRfun(resp(:,interval,1)',resp(:,interval,2)',g_kurt_sparse_FD,D);
g_kurt_sparse = SpaRIR(G_NSFD,S,D,weights,1);
ATR_kurt_sparse_1 = ATRfun(resp(:,interval,1)',resp(:,interval,2)',g_kurt_sparse,D);

% Sparse reconstruction of the relative impulse response with oversampling
% factor 2
g_kurt_sparse_2 = SpaRIR(G_NSFD,S,D,weights,2);
ATR_kurt_sparse_2 = ATRfun(resp(:,interval,1)',resp(:,interval,2)',g_kurt_sparse_2,D);

%% Display results
clc
disp('-------------|----------------------')
disp('   method    | attenuation rate [dB]')
disp('-------------|----------------------')
disp('------ dense oracle estimates-------')
disp(['oracle TD    | ' num2str(ATR_oracle_TD)])
disp(['oracle FD    | ' num2str(ATR_oracle_FD)])
disp(['oracle NSDF  | ' num2str(ATR_oracle_NSFD)])
disp('-------- dense noisy estimates -----')
disp(['noisy FD     | ' num2str(ATR_FD)])
disp(['noisy NSDF   | ' num2str(ATR_NSFD)])
disp('------- sparse noisy estimates -----')
disp('--- initial estimator: noisy FD ----')
disp(['oracle select| ' num2str(ATR_oracle_sparse_FD_1)])
disp(['kurtosis sel.| ' num2str(ATR_kurt_sparse_FD_1)])
disp('--- initial estimator: noisy NSFD --')
disp(['oracle select| ' num2str(ATR_oracle_sparse_1)])
disp(['kurtosis sel.| ' num2str(ATR_kurt_sparse_1)])
disp('----- (oversampling factor 2) ------')
disp(['oracle select| ' num2str(ATR_oracle_sparse_2)])
disp(['kurtosis sel.| ' num2str(ATR_kurt_sparse_2)])

% try to listen to the output of the blocking matrix
%soundsc(x(:,interval),Fs)

% oracle TD
%soundsc(BMoutput(x(:,interval)',h_TD,D),Fs)

% noisy FD estimate
%soundsc(BMoutput(x(:,interval)',g_FD,D),Fs)

% sparse kurtosis-based-selection estimate
%soundsc(BMoutput(x(:,interval)',g_kurt_sparse,D),Fs)

